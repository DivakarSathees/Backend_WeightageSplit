using NUnit.Framework;
using System;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
[TestFixture]
public class UnitTest2
{
    private HttpClient _httpClient;
    private string _generatedToken;
    
    [SetUp]
    public void Setup()
    {
        _httpClient = new HttpClient();
        _httpClient.BaseAddress = new Uri("http://localhost:8080");
    }
    
    [Test, Order(1)]
    public async Task Backend_TestPostCarservice()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();

    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

    //string token = responseMap.token;
    //Assert.IsNotNull(token);
        string uniqueId = Guid.NewGuid().ToString();
        
        int uniqueid = 123;
        string uniquecar_name = $"abcd{uniqueId}";
        string uniquecar_number = $"abcd{uniqueId}";
        string uniquecar_varient = $"abcd{uniqueId}";
        string uniquecustomer_name = $"abcd{uniqueId}";
        string uniquecomplaint = $"abcd{uniqueId}";
        string uniquephonenumber = $"abcd{uniqueId}";
        string uniqueaddress = $"abcd{uniqueId}";
        string requestBody2 = $"{{\"id\" : {uniqueid},\"car_name\" : \"{uniquecar_name}\",\"car_number\" : \"{uniquecar_number}\",\"car_varient\" : \"{uniquecar_varient}\",\"customer_name\" : \"{uniquecustomer_name}\",\"complaint\" : \"{uniquecomplaint}\",\"phonenumber\" : \"{uniquephonenumber}\",\"address\" : \"{uniqueaddress}\" }}";
    //    _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
        HttpResponseMessage response3 = await _httpClient.PostAsync("/api/Carservice", new StringContent(requestBody2, Encoding.UTF8, "application/json"));

        Assert.AreEqual(HttpStatusCode.OK, response3.StatusCode);
    }
    
    [Test, Order(2)]
    public async Task Backend_TestGetCarservice()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();
    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);
    //string token = responseMap.token;
    //Assert.IsNotNull(token);
    //_httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);

        HttpResponseMessage response = await _httpClient.GetAsync("/api/Carservice");

        Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
    }
    [Test, Order(1)]
    public async Task Backend_TestPostCarserviceController()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();

    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

    //string token = responseMap.token;
    //Assert.IsNotNull(token);
        string uniqueId = Guid.NewGuid().ToString();
        
        string requestBody2 = $"{{
    //    _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
        HttpResponseMessage response3 = await _httpClient.PostAsync("/api/CarserviceController", new StringContent(requestBody2, Encoding.UTF8, "application/json"));

        Assert.AreEqual(HttpStatusCode.OK, response3.StatusCode);
    }
    
    [Test, Order(2)]
    public async Task Backend_TestGetCarserviceController()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();
    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);
    //string token = responseMap.token;
    //Assert.IsNotNull(token);
    //_httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);

        HttpResponseMessage response = await _httpClient.GetAsync("/api/CarserviceController");

        Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
    }
    [Test, Order(1)]
    public async Task Backend_TestPostJob()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();

    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

    //string token = responseMap.token;
    //Assert.IsNotNull(token);
        string uniqueId = Guid.NewGuid().ToString();
        
        int uniqueJobID = 123;
        string uniqueJobTitle = $"abcd{uniqueId}";
        string uniqueDepartment = $"abcd{uniqueId}";
        string uniqueLocation = $"abcd{uniqueId}";
        string uniqueResponsibility = $"abcd{uniqueId}";
        string uniqueQualification = $"abcd{uniqueId}";
        DateTime uniqueDeadLine = DateTime.Now;
        string requestBody2 = $"{{\"JobID\" : {uniqueJobID},\"JobTitle\" : \"{uniqueJobTitle}\",\"Department\" : \"{uniqueDepartment}\",\"Location\" : \"{uniqueLocation}\",\"Responsibility\" : \"{uniqueResponsibility}\",\"Qualification\" : \"{uniqueQualification}\",\"DeadLine\" : \"{uniqueDeadLine}\" }}";
    //    _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
        HttpResponseMessage response3 = await _httpClient.PostAsync("/api/Job", new StringContent(requestBody2, Encoding.UTF8, "application/json"));

        Assert.AreEqual(HttpStatusCode.OK, response3.StatusCode);
    }
    
    [Test, Order(2)]
    public async Task Backend_TestGetJob()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();
    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);
    //string token = responseMap.token;
    //Assert.IsNotNull(token);
    //_httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);

        HttpResponseMessage response = await _httpClient.GetAsync("/api/Job");

        Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
    }
    [Test, Order(1)]
    public async Task Backend_TestPostOtherDbContext()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();

    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

    //string token = responseMap.token;
    //Assert.IsNotNull(token);
        string uniqueId = Guid.NewGuid().ToString();
        
        string requestBody2 = $"{{
    //    _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
        HttpResponseMessage response3 = await _httpClient.PostAsync("/api/OtherDbContext", new StringContent(requestBody2, Encoding.UTF8, "application/json"));

        Assert.AreEqual(HttpStatusCode.OK, response3.StatusCode);
    }
    
    [Test, Order(2)]
    public async Task Backend_TestGetOtherDbContext()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();
    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);
    //string token = responseMap.token;
    //Assert.IsNotNull(token);
    //_httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);

        HttpResponseMessage response = await _httpClient.GetAsync("/api/OtherDbContext");

        Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
    }
    [Test, Order(1)]
    public async Task Backend_TestPostShoppingCartController()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();

    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);

    //string token = responseMap.token;
    //Assert.IsNotNull(token);
        string uniqueId = Guid.NewGuid().ToString();
        
        string requestBody2 = $"{{
    //    _httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
        HttpResponseMessage response3 = await _httpClient.PostAsync("/api/ShoppingCartController", new StringContent(requestBody2, Encoding.UTF8, "application/json"));

        Assert.AreEqual(HttpStatusCode.OK, response3.StatusCode);
    }
    
    [Test, Order(2)]
    public async Task Backend_TestGetShoppingCartController()
    {
    //string responseBody = await loginResponse.Content.ReadAsStringAsync();
    //dynamic responseMap = JsonConvert.DeserializeObject(responseBody);
    //string token = responseMap.token;
    //Assert.IsNotNull(token);
    //_httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);

        HttpResponseMessage response = await _httpClient.GetAsync("/api/ShoppingCartController");

        Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
    }
}
