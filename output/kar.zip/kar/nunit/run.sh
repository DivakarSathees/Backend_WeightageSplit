#!/bin/bash  
if [ ! -d "/home/coder/project/workspace/dotnetapp/" ]
then
    cp -r /home/coder/project/workspace/nunit/dotnetapp /home/coder/project/workspace/;
fi
if [ -d "/home/coder/project/workspace/dotnetapp/" ]
then
    echo "project folder present"
    if [ -d "/home/coder/project/workspace/dotnetapp/" ]
    then
        cp -r /home/coder/project/workspace/nunit/test/TestProject /home/coder/project/workspace/;
        cp -r /home/coder/project/workspace/nunit/test/dotnetapp.sln /home/coder/project/workspace/dotnetapp/;
        cd /home/coder/project/workspace/dotnetapp || exit;
        dotnet clean;
        dotnet build && dotnet test -l "console;verbosity=normal";
    else
        echo "Backend_TestPostCarservice FAILED";
        echo "Backend_TestGetCarservice FAILED";
        echo "Backend_TestPostCarserviceController FAILED";
        echo "Backend_TestGetCarserviceController FAILED";
        echo "Backend_TestPostJob FAILED";
        echo "Backend_TestGetJob FAILED";
        echo "Backend_TestPostOtherDbContext FAILED";
        echo "Backend_TestGetOtherDbContext FAILED";
        echo "Backend_TestPostShoppingCartController FAILED";
        echo "Backend_TestGetShoppingCartController FAILED";
    fi
else
    echo "Backend_TestPostCarservice FAILED";
    echo "Backend_TestGetCarservice FAILED";
    echo "Backend_TestPostCarserviceController FAILED";
    echo "Backend_TestGetCarserviceController FAILED";
    echo "Backend_TestPostJob FAILED";
    echo "Backend_TestGetJob FAILED";
    echo "Backend_TestPostOtherDbContext FAILED";
    echo "Backend_TestGetOtherDbContext FAILED";
    echo "Backend_TestPostShoppingCartController FAILED";
    echo "Backend_TestGetShoppingCartController FAILED";
fi
