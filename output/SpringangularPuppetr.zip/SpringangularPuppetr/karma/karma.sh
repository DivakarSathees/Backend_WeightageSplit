#!/bin/bash
export CHROME_BIN=/usr/bin/chromium
if [ ! -d "/home/coder/project/workspace/angularapp" ]
then
    cp -r /home/coder/project/workspace/karma/angularapp /home/coder/project/workspace/;
fi

if [ -d "/home/coder/project/workspace/angularapp" ]
then
    echo "project folder present"
    cp /home/coder/project/workspace/karma/karma.conf.js /home/coder/project/workspace/angularapp/karma.conf.js;
    # checking for admin.service.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/services/admin.service.ts" ]
    then
        cp /home/coder/project/workspace/karma/admin.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/admin.service.spec.ts;
    else
        echo "Week5_Day5_should retrieve teams from the backend FAILED";
        echo "Week5_Day5_should create a new team via the backend FAILED";
        echo "Week5_Day5_should retrieve players from the backend FAILED";
    fi

    # checking for app-routing.module.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/modules" ]
    then
        cp /home/coder/project/workspace/karma/app-routing.module.spec.ts /home/coder/project/workspace/angularapp/src/app/modules/app-routing.module.spec.ts;
    else
        echo "Week5_Day1_should route to home page by default FAILED";
        echo "Week5_Day1_should route to admin page FAILED";
        echo "Week5_Day1_should route to organizer page FAILED";
        echo "Week5_Day1_should route to default path for invalid paths FAILED";
    fi

    # checking for login.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/login" ]
    then
        cp /home/coder/project/workspace/karma/login.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/login/login.component.spec.ts;
    else
        echo "Week4_day5_LoginComponent_CreateComponent FAILED";
        echo "Week5_Day5_call_login_method_on_admin_login FAILED";
        echo "Week5_Day5_should_navigate_to_admin_on_admin_login FAILED";
        echo "Week5_Day5_should_call_login_method_on_organizer_login FAILED";
        echo "Week5_Day5_should_navigate to organizer on organizer login FAILED";
        echo "Week4_Day6_should show username required error message FAILED";
        echo "Week4_Day6_should show password required error message FAILED";
    fi

    # checking for player.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/player" ]
    then
        cp /home/coder/project/workspace/karma/player.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/player/player.component.spec.ts;
    else
        echo "Week4_Day5_create_Player_component FAILED";
        echo "Week4_Day5_should have edit buttons for each player FAILED";
        echo "Week4_Day5_should have delete buttons for each player FAILED";
        echo "Week4_Day5_check the bidding amount FAILED";
    fi

    # checking for registration.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/registration" ]
    then
        cp /home/coder/project/workspace/karma/registration.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/registration/registration.component.spec.ts;
    else
        echo "Week4_Day6_should show username required error message on register page FAILED";
        echo "Week4_Day6_should show password required error message on register page FAILED";
        echo "Week4_Day6_should show password complexity error message on register page FAILED";
        echo "Week4_Day6_should show confirm password required error message on register page FAILED";
        echo "Week4_Day6_should show passwords mismatch error message on register page FAILED";
    fi

    if [ -d "/home/coder/project/workspace/angularapp/node_modules" ]; 
    then
        cd /home/coder/project/workspace/angularapp/
        npm test;
    else
        cd /home/coder/project/workspace/angularapp/
        yes | npm install
        npm test
    fi 
else   
    echo "Week5_Day5_should retrieve teams from the backend FAILED";
    echo "Week5_Day5_should create a new team via the backend FAILED";
    echo "Week5_Day5_should retrieve players from the backend FAILED";
    echo "Week5_Day1_should route to home page by default FAILED";
    echo "Week5_Day1_should route to admin page FAILED";
    echo "Week5_Day1_should route to organizer page FAILED";
    echo "Week5_Day1_should route to default path for invalid paths FAILED";
    echo "Week4_day5_LoginComponent_CreateComponent FAILED";
    echo "Week5_Day5_call_login_method_on_admin_login FAILED";
    echo "Week5_Day5_should_navigate_to_admin_on_admin_login FAILED";
    echo "Week5_Day5_should_call_login_method_on_organizer_login FAILED";
    echo "Week5_Day5_should_navigate to organizer on organizer login FAILED";
    echo "Week4_Day6_should show username required error message FAILED";
    echo "Week4_Day6_should show password required error message FAILED";
    echo "Week4_Day5_create_Player_component FAILED";
    echo "Week4_Day5_should have edit buttons for each player FAILED";
    echo "Week4_Day5_should have delete buttons for each player FAILED";
    echo "Week4_Day5_check the bidding amount FAILED";
    echo "Week4_Day6_should show username required error message on register page FAILED";
    echo "Week4_Day6_should show password required error message on register page FAILED";
    echo "Week4_Day6_should show password complexity error message on register page FAILED";
    echo "Week4_Day6_should show confirm password required error message on register page FAILED";
    echo "Week4_Day6_should show passwords mismatch error message on register page FAILED";
fi
