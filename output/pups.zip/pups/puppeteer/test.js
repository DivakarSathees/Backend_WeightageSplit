const puppeteer = require('puppeteer');


(async () => {
  const browser = await puppeteer.launch({
    headless: false,
    args: ['--headless', '--disable-gpu', '--remote-debugging-port=9222', '--no-sandbox', '--disable-setuid-sandbox']
  });
  const page = await browser.newPage();
  try {
    await page.goto('https://api.example.com');
        await page.setViewport({
          width:1200,
          height:800,
        })
        await page.screenshot({path: 'example.png'});                   
        await page.type('#age', '25');
        await page.click('#button');
        const ageGroup = await page.$eval('p', p => p.textContent);
        if(ageGroup == "The person is in the age group: Adult")
          console.log("TESTCASE:test_case7:success");
        else
          console.log("TESTCASE:test_case7:failure");
  }
  catch (e) {
    console.log('TESTCASE:test_case7:failure');
  }

  const page1 = await browser.newPage();
  try {
    await page1.goto('https://api.example.com');
      await page1.setViewport({
        width:1200,
        height:800,
      })
      await page1.screenshot({path: 'example.png'});
      await page1.type('#age', '0');
      await page1.click('#button');
      const ageGroup = await page1.$eval('p', p => p.textContent);
      if(ageGroup == "The person is in the age group: Foetus Infancy")
        console.log("TESTCASE:test_case8:success");
      else
        console.log("TESTCASE:test_case8:failure");
  }
  catch (e) {
    console.log('TESTCASE:test_case8:failure');
  }

  const page2 = await browser.newPage();
  try {
    await page2.goto('https://api.example.com');
          await page2.setViewport({
            width:1200,
            height:800,
          })
          await page2.screenshot({path: 'example.png'});
          await page2.type('#age', '2');
          await page2.click('#button');
          const ageGroup = await page2.$eval('p', p => p.textContent);
          if(ageGroup == "The person is in the age group: Toddler years")
            console.log("TESTCASE:test_case9:success");
          else
            console.log("TESTCASE:test_case9:failure");
  }
  catch (e) {
    console.log('TESTCASE:test_case9:failure');
  }

  const page3 = await browser.newPage();
  try {
    await page3.goto('https://api.example.com');
      await page3.setViewport({
        width:1200,
        height:800,
      })
      await page3.screenshot({path: 'example.png'});
      await page3.type('#age', '17');
      await page3.click('#button');
      const ageGroup = await page3.$eval('p', p => p.textContent);
      if(ageGroup == "The person is in the age group: Teenage")
        console.log("TESTCASE:test_case10:success");
      else
        console.log("TESTCASE:test_case10:failure");
  }
  catch (e) {
    console.log('TESTCASE:test_case10:failure');
  }

   finally {
    await page.close();
    await page1.close();
    await page2.close();
    await page3.close();
    await browser.close();
  }
})();




