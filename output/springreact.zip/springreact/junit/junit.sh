#!/bin/bash
cp -r /home/coder/project/workspace/junit/test /home/coder/project/workspace/springapp/src/;
cd /home/coder/project/workspace/springapp/;
mvn clean test
