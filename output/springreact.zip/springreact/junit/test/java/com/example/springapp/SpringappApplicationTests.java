package com.example.springapp;
 
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
 
import java.io.File;
import java.lang.reflect.Field;
import java.util.Map;
 
import javax.persistence.OneToMany;
 
import org.junit.FixMethodOrder;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
 
import com.fasterxml.jackson.databind.ObjectMapper;
 
import org.junit.runners.MethodSorters;
 
@RunWith(SpringJUnit4ClassRunner.class) 
@SpringBootTest(classes = SpringappApplication.class)
@AutoConfigureMockMvc
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
class SpringappApplicationTests {
	 @Autowired
	    private MockMvc mockMvc;
 
	 private String generatedToken;
 
		@Test
		void test1RegisterUser() throws Exception {
			String requestBody = "{\"userid\":1 ,\"email\": \"abcd@gmail.com\", \"password\": \"abc\", \"username\": \"abcd\", \"userRole\": \"STUDENT\"}";
			mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
					.contentType(MediaType.APPLICATION_JSON)
					.content(requestBody)
					.accept(MediaType.APPLICATION_JSON))
					.andExpect(status().isOk())
					.andExpect(jsonPath("$").value(true))
					.andReturn();
		}
 
        @Test
		void test2RegisterAdmin() throws Exception {
			String requestBody = "{\"userid\":2 ,\"email\": \"123@gmail.com\", \"password\": \"abc\", \"username\": \"abc\", \"userRole\": \"ADMIN\"}";
			mockMvc.perform(MockMvcRequestBuilders.post("/auth/register")
					.contentType(MediaType.APPLICATION_JSON)
					.content(requestBody)
					.accept(MediaType.APPLICATION_JSON))
					.andExpect(status().isOk())
					.andExpect(jsonPath("$").value(true))
					.andReturn();
		}
 
        
 
 
	@Test
    public void test3LoginUserEndpoint() throws Exception {
       test2RegisterAdmin();
            String requestBody = "{\"email\": \"abcd@gmail.com\", \"password\": \"abc\", \"userRole\": \"STUDENT\"}";
            MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestBody))
                    .andExpect(MockMvcResultMatchers.status().isOk())
                    .andReturn();
            String responseString = result.getResponse().getContentAsString();
            ObjectMapper mapper = new ObjectMapper();
            Map<String, String> responseMap = mapper.readValue(responseString, Map.class);
            String token = responseMap.get("token");
            generatedToken = token;
            assertNotNull(token);
    }
	@Test
    public void test4LoginAdminEndpoint() throws Exception {
        test1RegisterUser();
            String requestBody = "{\"email\": \"123@gmail.com\", \"password\": \"abc\", \"userRole\": \"ADMIN\"}";
            MvcResult result = mockMvc.perform(MockMvcRequestBuilders.post("/auth/login")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(requestBody))
                    .andExpect(MockMvcResultMatchers.status().isOk())
                    .andReturn();
            String responseString = result.getResponse().getContentAsString();
            ObjectMapper mapper = new ObjectMapper();
            Map<String, String> responseMap = mapper.readValue(responseString, Map.class);
            String token = responseMap.get("token");
            generatedToken = token;
            assertNotNull(token);
    }


 
 
    @Test  
    public void backend_testSaveCourseByAdmin() throws Exception {
		test4LoginAdminEndpoint(); 
    	String requestBody = "{"
        + "\"courseID\": 1,"
        + "\"courseName\": \"C++\","
        + "\"duration\": \"Sample Course\","
        + "\"description\": \"This is a test Course.\","
        + "\"cost\": 500"
        + "}";
 
    	mockMvc.perform(MockMvcRequestBuilders.post("/api/course")
				.header("Authorization", "Bearer " + generatedToken)
    			.contentType(MediaType.APPLICATION_JSON)
				.content(requestBody).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
				// .andExpect(MockMvcResultMatchers.content().string("true")) // Correct way to
				// validate boolean response
				.andReturn();
    }


		@Test
    public void backend_testGetAllCourseByAdmin() throws Exception {
		test4LoginAdminEndpoint();    	
    	mockMvc.perform(MockMvcRequestBuilders.get("/api/course")
				.header("Authorization", "Bearer " + generatedToken)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(print())
        .andExpect(content().contentType("application/json"))
			.andExpect(jsonPath("$").isArray())
			.andReturn();
	}
    @Test
    public void backend_testGetOneCourseByAdmin() throws Exception {
    	test4LoginAdminEndpoint();    	
    	mockMvc.perform(MockMvcRequestBuilders.get("/api/course/1")
				.header("Authorization", "Bearer " + generatedToken)
    			.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
				// .andExpect(MockMvcResultMatchers.content().string("true")) // Correct way to
				// validate boolean response
				.andReturn();
    }
 
	@Test
	public void backend_testCourseHasOneToManyAnnotation() {
		try {
			// Use reflection to get the Class object for the Course class
			Class<?> courseClass = Class.forName("com.example.springapp.model.Course");

			// Get all declared fields in the Course class
			Field[] declaredFields = courseClass.getDeclaredFields();

			// Check each field for the @OneToMany annotation
			boolean hasOneToMany = false;
			for (Field field : declaredFields) {
				if (field.isAnnotationPresent(OneToMany.class)) {
					hasOneToMany = true;
					break; // Stop checking once we find one field with @OneToMany
				}
			}

			// If no field with @OneToMany is found, fail the test
			if (!hasOneToMany) {
				fail("No field with @OneToMany annotation found in Course class.");
			}

		} catch (ClassNotFoundException e) {
			// If the class is not found, fail the test
			fail("Class not found: " + e.getMessage());
		}
	}
 
    @Test
    public void backend_testUpdateCourseByAdmin() throws Exception {
    	test4LoginAdminEndpoint(); 
    	String requestBody = "{"
        + "\"courseID\": 1,"
        + "\"courseName\": \"C++\","
        + "\"duration\": \"12 weeks\","
        + "\"description\": \"This is a test Course.\","
        + "\"cost\": 500"
        + "}";
    	mockMvc.perform(MockMvcRequestBuilders.put("/api/course/1")
				.header("Authorization", "Bearer " + generatedToken)
    			.contentType(MediaType.APPLICATION_JSON)
				.content(requestBody).accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
				// .andExpect(MockMvcResultMatchers.content().string("true")) // Correct way to
				// validate boolean response
				.andReturn();
    }
 
     @Test  
    public void backend_testGetAllEnquiryByAdmin() throws Exception {
    	test4LoginAdminEndpoint();  	
    	mockMvc.perform(MockMvcRequestBuilders.get("/api/enquiry")
				.header("Authorization", "Bearer " + generatedToken)
				.contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
        .andDo(print())
        .andExpect(content().contentType("application/json"))
			.andExpect(jsonPath("$").isArray())
			.andReturn();
    }
	@Test 
    public void backend_testOneEnquiryByAdmin() throws Exception {
    	test4LoginAdminEndpoint();   	
    	mockMvc.perform(MockMvcRequestBuilders.get("/api/enquiry/1")
				.header("Authorization", "Bearer " + generatedToken)
    			.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
				// .andExpect(MockMvcResultMatchers.content().string("true")) // Correct way to
				// validate boolean response
				.andReturn();
    }
	//userby Id
    @Test
    public void backend_testGetOneUserEnquiryByAdmin() throws Exception {
    	test4LoginAdminEndpoint();    	
    	mockMvc.perform(MockMvcRequestBuilders.get("/api/user/1")
				.header("Authorization", "Bearer " + generatedToken)
    			.contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk())
				// .andExpect(MockMvcResultMatchers.content().string("true")) // Correct way to
				// validate boolean response
				.andReturn();
    }
 
 
   }