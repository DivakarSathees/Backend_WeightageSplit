#!/bin/bash
export CHROME_BIN=/usr/bin/chromium
if [ ! -d "/home/coder/project/workspace/angularapp" ]
then
    cp -r /home/coder/project/workspace/karma/angularapp /home/coder/project/workspace/;
fi

if [ -d "/home/coder/project/workspace/angularapp" ]
then
    echo "project folder present"
    find /home/coder/project/workspace/angularapp -type f -name "*.spec.ts" -delete
    cp /home/coder/project/workspace/karma/karma.conf.js /home/coder/project/workspace/angularapp/karma.conf.js;
    cp /home/coder/project/workspace/karma/test.ts /home/coder/project/workspace/angularapp/src/test.ts;
    cp /home/coder/project/workspace/karma/tsconfig.spec.json /home/coder/project/workspace/angularapp/tsconfig.spec.json;
    # checking for admin.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/admin" ]
    then
        cp /home/coder/project/workspace/karma/admin.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/admin/admin.component.spec.ts;
    else
        echo "Week5_Day2_should add a new player on form submission FAILED";
        echo "Week5_Day3_should get teams and players on initialization FAILED";
        echo "Week5_Day3_should display player list FAILED";
    fi

    # checking for admin.service.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/services/admin.service.ts" ]
    then
        cp /home/coder/project/workspace/karma/admin.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/admin.service.spec.ts;
    else
        echo "Week5_Day3_should create AdminServices FAILED";
    fi

    # checking for app-routing.module.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/modules" ]
    then
        cp /home/coder/project/workspace/karma/app-routing.module.spec.ts /home/coder/project/workspace/angularapp/src/app/modules/app-routing.module.spec.ts;
    else
        echo "Week5_Day1_should route to home page by default FAILED";
        echo "Week5_Day1_should route to admin page FAILED";
        echo "Week5_Day2_should route to organizer page FAILED";
        echo "Week5_Day1_should route to login page FAILED";
        echo "Week5_Day1_should route to register page FAILED";
        echo "Week5_Day2_should route to default path for invalid paths FAILED";
    fi

    # checking for auth.service.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/services/auth.service.ts" ]
    then
        cp /home/coder/project/workspace/karma/auth.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/auth.service.spec.ts;
    else
        echo "Week5_Day4_should_create_authServices FAILED";
    fi

    # checking for error.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/error" ]
    then
        cp /home/coder/project/workspace/karma/error.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/error/error.component.spec.ts;
    else
        echo "Week5_Day2_should create the error component FAILED";
        echo "Week5_Day2_should display the error message on error page for invalid navigation FAILED";
    fi

    # checking for home.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/home" ]
    then
        cp /home/coder/project/workspace/karma/home.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/home/home.component.spec.ts;
    else
        echo "Week5_Day1_should create the HomeComponent FAILED";
    fi

    # checking for login.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/login" ]
    then
        cp /home/coder/project/workspace/karma/login.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/login/login.component.spec.ts;
    else
        echo "Week5_day1_LoginComponent FAILED";
        echo "Week5_Day4_call_login_method_on_admin_login FAILED";
        echo "Week5_Day4_should_navigate_to_admin_on_admin_login FAILED";
        echo "Week5_Day4_should_call_login_method_on_organizer_login FAILED";
        echo "Week5_Day4_should_navigate to organizer on organizer login FAILED";
        echo "Week5_Day4_should have empty username and password initially FAILED";
        echo "Week5_Day4_should call login method on form submission FAILED";
    fi

    # checking for organizer.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/organizer" ]
    then
        cp /home/coder/project/workspace/karma/organizer.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/organizer/organizer.component.spec.ts;
    else
        echo "Week5_Day2_should reset player filter when category is empty FAILED";
        echo "Week5_Day2_should display unsold players FAILED";
        echo "Week5_Day2_should display team list FAILED";
        echo "Week5_Day2_should fetch unsold players on initialization FAILED";
    fi

    # checking for organizer.service.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/services/organizer.service.ts" ]
    then
        cp /home/coder/project/workspace/karma/organizer.service.spec.ts /home/coder/project/workspace/angularapp/src/app/services/organizer.service.spec.ts;
    else
        echo "Week5_Day3_should create organizerServices FAILED";
    fi

    # checking for player.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/player" ]
    then
        cp /home/coder/project/workspace/karma/player.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/player/player.component.spec.ts;
    else
        echo "Week4_Day4_create_Player_component FAILED";
    fi

    # checking for player.model.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/models/player.model.ts" ]
    then
        cp /home/coder/project/workspace/karma/player.model.spec.ts /home/coder/project/workspace/angularapp/src/app/models/player.model.spec.ts;
    else
        echo "Week4_Day3_should_create_Player_instance FAILED";
    fi

    # checking for team.component.spec.ts component
    if [ -d "/home/coder/project/workspace/angularapp/src/app/components/team" ]
    then
        cp /home/coder/project/workspace/karma/team.component.spec.ts /home/coder/project/workspace/angularapp/src/app/components/team/team.component.spec.ts;
    else
        echo "Week4_Day4_create_Team_Component FAILED";
    fi

    # checking for team.model.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/models/team.model.ts" ]
    then
        cp /home/coder/project/workspace/karma/team.model.spec.ts /home/coder/project/workspace/angularapp/src/app/models/team.model.spec.ts;
    else
        echo "Week4_Day3_create_Team_instance FAILED";
    fi

    # checking for user.model.spec.ts component
    if [ -e "/home/coder/project/workspace/angularapp/src/app/models/user.model.ts" ]
    then
        cp /home/coder/project/workspace/karma/user.model.spec.ts /home/coder/project/workspace/angularapp/src/app/models/user.model.spec.ts;
    else
        echo "Week4_Day3_should_create_User_instance FAILED";
    fi

    if [ -d "/home/coder/project/workspace/angularapp/node_modules" ]; 
    then
        cd /home/coder/project/workspace/angularapp/
        npm test;
    else
        cd /home/coder/project/workspace/angularapp/
        yes | npm install
        npm test
    fi 
else   
    echo "Week5_Day2_should add a new player on form submission FAILED";
    echo "Week5_Day3_should get teams and players on initialization FAILED";
    echo "Week5_Day3_should display player list FAILED";
    echo "Week5_Day3_should create AdminServices FAILED";
    echo "Week5_Day1_should route to home page by default FAILED";
    echo "Week5_Day1_should route to admin page FAILED";
    echo "Week5_Day2_should route to organizer page FAILED";
    echo "Week5_Day1_should route to login page FAILED";
    echo "Week5_Day1_should route to register page FAILED";
    echo "Week5_Day2_should route to default path for invalid paths FAILED";
    echo "Week5_Day4_should_create_authServices FAILED";
    echo "Week5_Day2_should create the error component FAILED";
    echo "Week5_Day2_should display the error message on error page for invalid navigation FAILED";
    echo "Week5_Day1_should create the HomeComponent FAILED";
    echo "Week5_day1_LoginComponent FAILED";
    echo "Week5_Day4_call_login_method_on_admin_login FAILED";
    echo "Week5_Day4_should_navigate_to_admin_on_admin_login FAILED";
    echo "Week5_Day4_should_call_login_method_on_organizer_login FAILED";
    echo "Week5_Day4_should_navigate to organizer on organizer login FAILED";
    echo "Week5_Day4_should have empty username and password initially FAILED";
    echo "Week5_Day4_should call login method on form submission FAILED";
    echo "Week5_Day2_should reset player filter when category is empty FAILED";
    echo "Week5_Day2_should display unsold players FAILED";
    echo "Week5_Day2_should display team list FAILED";
    echo "Week5_Day2_should fetch unsold players on initialization FAILED";
    echo "Week5_Day3_should create organizerServices FAILED";
    echo "Week4_Day4_create_Player_component FAILED";
    echo "Week4_Day3_should_create_Player_instance FAILED";
    echo "Week4_Day4_create_Team_Component FAILED";
    echo "Week4_Day3_create_Team_instance FAILED";
    echo "Week4_Day3_should_create_User_instance FAILED";
fi
